#!/usr/bin/env bash
# =================================================================
# Ruckus Unleashed Firmware Auto Downloader for Rocky Linux 8 (v1.2.5)
# =================================================================

set -e

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
GRAY='\033[0;90m'
NC='\033[0m' # No Color

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COOKIE_FILE="${SCRIPT_DIR}/cookies.txt"
PYTHON_SCRIPT="${SCRIPT_DIR}/get_ruckus_cookie.py"
BASE_URL="https://support.ruckuswireless.com"

RUCKUS_USER="${RUCKUS_USER:-}"
RUCKUS_PASS="${RUCKUS_PASS:-}"

echo -e "${CYAN}=======================================================${NC}"
echo -e "${CYAN}   Ruckus Unleashed Firmware Auto Downloader (v1.2.5)  ${NC}"
echo -e "${CYAN}=======================================================${NC}"

# -----------------------------------------------------------------
# [단계 0] Python 환경 및 필수 패키지 점검
# -----------------------------------------------------------------
echo -e "${YELLOW}[0/5] 필수 패키지 및 모듈 설치 상태 확인 중...${NC}"

if ! command -v python3 &> /dev/null; then
    echo -e "${YELLOW}[!] Python3가 설치되어 있지 않습니다. dnf로 설치합니다...${NC}"
    sudo dnf install -y python3 python3-pip
fi

PY_EXE="$(command -v python3)"

MODULES=("requests:requests" "bs4:beautifulsoup4" "lxml:lxml")

for item in "${MODULES[@]}"; do
    import_name="${item%%:*}"
    pkg_name="${item##*:}"
    
    if ! "$PY_EXE" -c "import importlib.util, sys; sys.exit(0 if importlib.util.find_spec('$import_name') else 1)" &>/dev/null; then
        echo -e "${YELLOW}[!] 파이썬 ${pkg_name} (${import_name}) 모듈이 없습니다. 자동 설치를 진행합니다...${NC}"
        "$PY_EXE" -m pip install "$pkg_name" --quiet --user
    fi
done

echo -e "${GREEN}[+] 개발 및 실행 환경 검사 완료.${NC}"
echo "-------------------------------------------------"

# -----------------------------------------------------------------
# [단계 1] 쿠키 확인 및 로그인
# -----------------------------------------------------------------
echo -e "${YELLOW}[1/5] 로그인 세션(cookies.txt) 검사 중...${NC}"

if [ ! -f "$COOKIE_FILE" ]; then
    echo -e "${YELLOW}[!] 쿠키 파일이 없습니다. 로그인을 진행합니다.${NC}\n"

    [ -n "$RUCKUS_USER" ] && RUCKUS_USER="$(echo "$RUCKUS_USER" | xargs)"
    [ -n "$RUCKUS_PASS" ] && RUCKUS_PASS="$(echo "$RUCKUS_PASS" | xargs)"

    if [ -z "$RUCKUS_USER" ]; then
        echo -e "${CYAN}Ruckus 이메일 계정을 입력하세요:${NC}"
        read -r RUCKUS_USER
    fi

    if [ -z "$RUCKUS_PASS" ]; then
        echo -e "${CYAN}Ruckus 비밀번호를 입력하세요:${NC}"
        read -rs RUCKUS_PASS
        echo ""
    fi

    echo -e "${YELLOW}[*] 파이썬 로그인 스크립트 실행 중...${NC}"
    "$PY_EXE" -u "$PYTHON_SCRIPT" -u "$RUCKUS_USER" -p "$RUCKUS_PASS" -o "$COOKIE_FILE" || true

    if [ ! -f "$COOKIE_FILE" ]; then
        echo -e "${RED}[-] 로그인 및 쿠키 생성 실패.${NC}"
        exit 1
    fi
    echo -e "${GREEN}[+] 쿠키 발급 완료!${NC}"
else
    echo -e "${GREEN}[+] 기존 cookies.txt 세션을 사용합니다.${NC}"
fi

sed -i '/^#/d; /^$/d' "$COOKIE_FILE"

# -----------------------------------------------------------------
# [단계 2] 동적 버전 목록 파싱 (200.x 버전 필터링)
# -----------------------------------------------------------------
echo -e "\n${YELLOW}[2/5] Unleashed 소프트웨어 동적 버전 검색 중...${NC}"

temp_py_ver="${SCRIPT_DIR}/temp_get_unleashed_versions.py"
cat << 'EOF' > "$temp_py_ver"
import sys, re, requests, urllib3
from bs4 import BeautifulSoup
urllib3.disable_warnings()

cookie_file, base_url = sys.argv[1], sys.argv[2]
session = requests.Session()
session.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})

with open(cookie_file, 'r', encoding='utf-8') as f:
    for line in f:
        if not line.startswith('#') and line.strip():
            p = line.strip().split('\t')
            if len(p) >= 7:
                session.cookies.set(p[5], p[6], domain=p[0].lstrip('.'))

url = f"{base_url}/products/82/filtered_products?type=software"
try:
    r = session.get(url, verify=False, timeout=15)
    soup = BeautifulSoup(r.text, 'html.parser')
    options = soup.select("#product_software_version select[name='version_filter'] option")
    
    versions = []
    for opt in options:
        val = opt.get('value', '').strip()
        if val.startswith('200.'):
            versions.append(val)
            
    for v in sorted(versions, key=lambda x: [int(p) for p in x.split('.')], reverse=True):
        print(v)
except Exception as e:
    sys.exit(1)
EOF

availableVersions=$("$PY_EXE" "$temp_py_ver" "$COOKIE_FILE" "$BASE_URL")
rm -f "$temp_py_ver"

if [ -z "$availableVersions" ]; then
    echo -e "${RED}[-] 200.x 버전을 찾지 못했거나 동적 목록을 불러오지 못했습니다.${NC}"
    exit 1
fi

# 메인 루프
while true; do
    # -----------------------------------------------------------------
    # [단계 3] 릴리스 버전 선택
    # -----------------------------------------------------------------
    echo -e "\n${YELLOW}[3/5] 다운로드할 Unleashed 버전을 선택하세요:${NC}"
    
    vIdx=1
    while IFS= read -r ver; do
        printf " %2d) Unleashed %s\n" "$vIdx" "$ver"
        vIdx=$((vIdx + 1))
    done <<< "$availableVersions"
    echo "  0) 종료"
    echo ""

    read -rp "버전 선택 번호: " verChoice

    if [ "$verChoice" = "0" ]; then exit 0; fi

    if ! [[ "$verChoice" =~ ^[0-9]+$ ]] || [ "$verChoice" -lt 1 ] || [ "$verChoice" -ge "$vIdx" ]; then
        echo -e "${RED}[-] 올바른 번호를 선택해주세요.${NC}"
        continue
    fi

    selectedVersion=$(echo "$availableVersions" | sed -n "${verChoice}p")
    echo -e "${CYAN}[*] 선택된 버전 ($selectedVersion)의 다운로드 URL을 수집 중입니다...${NC}"

    temp_py_urls="${SCRIPT_DIR}/temp_get_unleashed_urls.py"
    cat << 'EOF' > "$temp_py_urls"
import sys, re, requests, urllib3
urllib3.disable_warnings()

cookie_file, base_url, version = sys.argv[1], sys.argv[2], sys.argv[3]
session = requests.Session()
session.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})

with open(cookie_file, 'r', encoding='utf-8') as f:
    for line in f:
        if not line.startswith('#') and line.strip():
            p = line.strip().split('\t')
            if len(p) >= 7:
                session.cookies.set(p[5], p[6], domain=p[0].lstrip('.'))

url = f"{base_url}/products/82/filtered_products?version={version}&type=software"
urls = []
try:
    r = session.get(url, verify=False, timeout=15)
    matches = re.findall(r'href="(/documents/[^"]+|/software/[^"]+)"', r.text)
    for m in matches:
        if "unleashed" in m.lower() and "snmp" not in m.lower():
            urls.append(base_url + m)
except: pass

for u in sorted(list(set(urls))):
    print(u)
EOF

    extractedUrls=$("$PY_EXE" "$temp_py_urls" "$COOKIE_FILE" "$BASE_URL" "$selectedVersion")
    rm -f "$temp_py_urls"

    if [ -z "$extractedUrls" ]; then
        echo -e "${RED}[-] 해당 버전에서 다운로드할 수 있는 소프트웨어를 찾지 못했습니다.${NC}"
        continue
    fi

    # -----------------------------------------------------------------
    # [단계 4] 세부 항목 분석 및 다운로드 대상 선택
    # -----------------------------------------------------------------
    echo -e "\n${YELLOW}[4/5] 각 세부 항목의 파일 이름 및 용량 분석 중...${NC}"

    temp_py_details="${SCRIPT_DIR}/temp_get_unleashed_details.py"
    cat << 'EOF' > "$temp_py_details"
import sys, requests, urllib3
from bs4 import BeautifulSoup
urllib3.disable_warnings()

cookie_file = sys.argv[1]
urls = sys.argv[2:]

session = requests.Session()
session.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})

with open(cookie_file, 'r', encoding='utf-8') as f:
    for line in f:
        if not line.startswith('#') and line.strip():
            p = line.strip().split('\t')
            if len(p) >= 7:
                session.cookies.set(p[5], p[6], domain=p[0].lstrip('.'))

f_counter = 1
for page_url in urls:
    try:
        dr = session.get(page_url, verify=False, timeout=15)
        soup = BeautifulSoup(dr.text, 'html.parser')
        
        sw_title = "N/A"
        if soup.title:
            sw_title = soup.title.text.split('|')[0].strip()
            
        real_file_name = ""
        dt_fn = soup.find(lambda tag: tag.name == 'dt' and 'File Name:' in tag.text)
        if dt_fn and dt_fn.find_next_sibling('dd'):
            real_file_name = dt_fn.find_next_sibling('dd').text.strip()
        if not real_file_name:
            real_file_name = page_url.split('/')[-1]
            
        file_size = "N/A"
        dt_fs = soup.find(lambda tag: tag.name == 'dt' and 'File Size:' in tag.text)
        if dt_fs and dt_fs.find_next_sibling('dd'):
            file_size = dt_fs.find_next_sibling('dd').text.strip()

        print(f"{f_counter}\t{page_url}\t{real_file_name}\t{file_size}\t{sw_title}")
        f_counter += 1
    except: pass
EOF

    # URL 인자 전달
    readarray -t url_array <<< "$extractedUrls"
    file_raw_list=$("$PY_EXE" "$temp_py_details" "$COOKIE_FILE" "${url_array[@]}")
    rm -f "$temp_py_details"

    echo -e "\n${GRAY}----------------------------------------------------------------------------------------------------${NC}"
    printf "${CYAN}%-6s | %-45s | %-15s${NC}\n" "번호" "파일 이름 (File Name)" "용량 (Size)"
    echo -e "${GRAY}----------------------------------------------------------------------------------------------------${NC}"

    file_count=0
    while IFS=$'\t' read -r findex fpage freal fsize ftitle; do
        printf "%4s) | %-45s | %-15s\n" "$findex" "$freal" "$fsize"
        echo -e "     └─ ${GRAY}${ftitle}${NC}\n"
        file_count=$((file_count + 1))
    done <<< "$file_raw_list"

    echo -e "${GRAY}----------------------------------------------------------------------------------------------------${NC}"
    echo "  a) 전체 파일 모두 선택 (${file_count}개)"
    echo "  b) 이전 메뉴로 돌아가기 (버전 재선택)"
    echo "  0) 종료"
    echo -e "${GRAY}----------------------------------------------------------------------------------------------------${NC}"

    read -rp "다운로드할 파일 번호 선택 (예: 1, 3 또는 1-5): " fileChoice

    if [ "$fileChoice" = "0" ]; then exit 0; fi
    if [ "$fileChoice" = "b" ] || [ "$fileChoice" = "B" ]; then continue; fi

    selected_lines=""
    if [ "$fileChoice" = "a" ] || [ "$fileChoice" = "A" ] || [ -z "$fileChoice" ]; then
        selected_lines="$file_raw_list"
    else
        selected_indices=()
        IFS=' ' read -r -a tokens <<< "$(echo "$fileChoice" | tr ',' ' ')"
        for token in "${tokens[@]}"; do
            if [[ "$token" =~ ^([0-9]+)-([0-9]+)$ ]]; then
                start="${BASH_REMATCH[1]}"
                end="${BASH_REMATCH[2]}"
                for ((n=start; n<=end; n++)); do selected_indices+=("$n"); done
            elif [[ "$token" =~ ^[0-9]+$ ]]; then
                selected_indices+=("$token")
            fi
        done

        sorted_indices=$(printf "%s\n" "${selected_indices[@]}" | sort -nu)

        for num in $sorted_indices; do
            matched=$(echo "$file_raw_list" | awk -F'\t' -v n="$num" '$1 == n {print $0}')
            if [ -n "$matched" ]; then
                selected_lines="${selected_lines}${matched}"$'\n'
            fi
        done
        selected_lines="$(echo "$selected_lines" | sed '/^$/d')"
    fi

    if [ -z "$selected_lines" ]; then
        echo -e "${RED}[-] 선택된 파일이 없습니다.${NC}"
        continue
    fi

    # -----------------------------------------------------------------
    # [단계 5] 다운로드 진행 및 모델명 자동 보정
    # -----------------------------------------------------------------
    selected_count=$(echo "$selected_lines" | wc -l)
    echo -e "\n${YELLOW}[5/5] 다운로드 실행 중 (총 ${selected_count}개 파일)...${NC}"

    while IFS=$'\t' read -r findex fpage freal fsize ftitle; do
        cleanUrl="$(echo "$fpage" | xargs)"
        downloadUrl=$(echo "$cleanUrl" | sed 's|/software/|/software_downloads/|g; s|/documents/|/documents_downloads/|g')
        refererUrl="$cleanUrl"

        echo -e "\n${CYAN}[*] 다운로드 시도: ${downloadUrl}${NC}"

        headRaw=$(curl -k -s -I -b "$COOKIE_FILE" \
            -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)" \
            -H "Referer: $refererUrl" "$downloadUrl")

        targetFileName=""

        # 1. Location 헤더 파싱
        locLine=$(echo "$headRaw" | grep -i "^Location:" | head -n 1)
        if [ -n "$locLine" ]; then
            locUrl=$(echo "$locLine" | awk '{print $2}' | tr -d '\r')
            parsedName="${locUrl##*/}"
            parsedName="${parsedName%%\?*}"
            if [ -n "$parsedName" ]; then
                targetFileName=$(python3 -c "import urllib.parse, sys; print(urllib.parse.unquote(sys.argv[1]))" "$parsedName")
            fi
        fi

        # 2. Content-Disposition 파싱
        if [ -z "$targetFileName" ]; then
            cdLine=$(echo "$headRaw" | grep -i "filename=" | head -n 1)
            if [ -n "$cdLine" ]; then
                targetFileName=$(echo "$cdLine" | sed -E 's/.*filename="?([^";\r\n]+)"?.*/\1/')
            fi
        fi

        if [ -z "$targetFileName" ]; then
            targetFileName="$freal"
        fi

        # .bl7 모델명 보정 (URL Slug 패턴에서 AP 모델 추출: for-r510, for-t750 등)
        if [[ "$targetFileName" =~ \.bl7$ ]]; then
            if ! [[ "$targetFileName" =~ (R[0-9]+|H[0-9]+|T[0-9]+|M[0-9]+|ZF[0-9]+) ]]; then
                urlSlug="${cleanUrl##*/}"
                if [[ "$urlSlug" =~ for-(r[0-9]+|h[0-9]+|t[0-9]+|m[0-9]+|zf[0-9]+) ]]; then
                    modelName=$(echo "${BASH_REMATCH[1]}" | tr '[:lower:]' '[:upper:]')
                    targetFileName="${modelName}_${targetFileName}"
                    echo -e "${YELLOW}  [!] 모델명 보정 적용: ${targetFileName}${NC}"
                fi
            fi
        fi

		# 중복 파일 넘버링 로직 제거 (이어받기를 위해 원본 파일명 유지)
		saveFileName="$targetFileName"

		# (선택) 기존 파일이 존재할 경우 안내 메시지 출력
		if [ -f "$saveFileName" ]; then
			echo -e "${YELLOW} [!] 기존 파일 발견 -> '${saveFileName}' 이어서 다운로드를 시도합니다.${NC}"
		fi

		echo -e "${YELLOW} [+] 대상 파일명 확정: ${saveFileName}${NC}"

		curl -k -L -C - --retry 5 --retry-delay 3 --retry-max-time 600 -b "$COOKIE_FILE" \
			-H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)" \
			-H "Referer: $refererUrl" \
			-o "$saveFileName" "$downloadUrl"

        if [ -f "$saveFileName" ]; then
            echo -e "${GREEN}  [+] 다운로드 완료 및 저장: ${saveFileName}${NC}"
        fi

    done <<< "$selected_lines"

    echo -e "\n${GREEN}[+] 선택한 작업이 완료되었습니다.${NC}"
    
    read -rp "다른 파일도 다운로드하시겠습니까? (y/n): " continueChoice
    if [[ "$continueChoice" != "y" && "$continueChoice" != "Y" ]]; then break; fi
done

echo -e "${GREEN}[+] 모든 다운로드 과정 완료.${NC}"