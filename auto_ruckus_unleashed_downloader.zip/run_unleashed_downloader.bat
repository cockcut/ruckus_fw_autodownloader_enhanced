@echo off
chcp 65001 > nul
title Ruckus Unleashed Firmware Auto Downloader
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0auto_ruckus_unleashed_downloader.ps1"
pause