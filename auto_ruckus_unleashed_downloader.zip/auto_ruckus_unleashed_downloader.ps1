﻿# =================================================================
# Ruckus Unleashed Firmware Auto Downloader for Windows (v1.2.5)
# =================================================================

$ErrorActionPreference = "Stop"

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13

# -----------------------------------------------------------------
# 주요 경로 및 기본 변수 선언
# -----------------------------------------------------------------
$COOKIE_FILE   = Join-Path $PSScriptRoot "cookies.txt"
$PYTHON_SCRIPT = Join-Path $PSScriptRoot "get_ruckus_cookie.py"
$BASE_URL      = "https://support.ruckuswireless.com"

$RUCKUS_USER = $env:RUCKUS_USER
$RUCKUS_PASS = $env:RUCKUS_PASS

Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host "   Ruckus Unleashed Firmware Auto Downloader (v1.2.5)" -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan

# -----------------------------------------------------------------
# [단계 0] Python 환경 및 필수 패키지 점검
# -----------------------------------------------------------------
Write-Host "[0/5] 필수 패키지 및 모듈 설치 상태 확인 중..." -ForegroundColor Yellow

# 파이썬 실행 파일 존재 여부 확인 (WindowsApps의 바로가기 스텁 제외)
$pythonCmd = Get-Command python -ErrorAction SilentlyContinue
if (-not $pythonCmd -or $pythonCmd.Source -match "WindowsApps") {
    Write-Host "[!] Python이 설치되어 있지 않습니다. winget으로 설치를 진행합니다..." -ForegroundColor Yellow
    
    # msstore 오류 방지를 위해 --source winget 명시 및 msstore 소스 정리 시도
    winget install --id Python.Python.3.12 --source winget --scope user --silent --accept-package-agreements --accept-source-agreements
    
    # PATH 환경 변수 즉시 반영
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
}

# 파이썬 절대 경로 재확인
$pyExe = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $pyExe -or $pyExe -match "WindowsApps") {
    $pyExe = Join-Path $env:LocalAppData "Programs\Python\Python312\python.exe"
}

if (-not (Test-Path $pyExe)) {
    Write-Host "[-] Python 설치 또는 경로 인식에 실패했습니다. 파이썬을 수동으로 설치 후 다시 실행해 주세요." -ForegroundColor Red
    exit 1
}

$modules = @{
    "requests" = "requests"
    "bs4"      = "beautifulsoup4"
    "lxml"     = "lxml"
}

foreach ($importName in $modules.Keys) {
    $pkgName = $modules[$importName]
    
    # importlib.util.find_spec을 활용한 한 줄 모듈 존재 확인 (SyntaxError 예방)
    $checkScript = "import sys, importlib.util; sys.exit(0 if importlib.util.find_spec('$importName') else 1)"
    & "$pyExe" -c "$checkScript"
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[!] 파이썬 $pkgName ($importName) 모듈이 없습니다. 자동 설치를 진행합니다..." -ForegroundColor Yellow
        & "$pyExe" -m pip install $pkgName --quiet
    }
}
Write-Host "[+] 개발 및 실행 환경 검사 완료." -ForegroundColor Green
Write-Host "-------------------------------------------------"

# -----------------------------------------------------------------
# [단계 1] 쿠키 확인 및 로그인
# -----------------------------------------------------------------
Write-Host "[1/5] 로그인 세션(cookies.txt) 검사 중..." -ForegroundColor Yellow

if (-not (Test-Path $COOKIE_FILE)) {
    Write-Host "[!] 쿠키 파일이 없습니다. 로그인을 진행합니다." -ForegroundColor Yellow
    Write-Host ""

    if ($RUCKUS_USER) { $RUCKUS_USER = $RUCKUS_USER.Trim() }
    if ($RUCKUS_PASS) { $RUCKUS_PASS = $RUCKUS_PASS.Trim() }

    if ([string]::IsNullOrWhiteSpace($RUCKUS_USER)) {
        Write-Host "Ruckus 이메일 계정을 입력하세요:" -ForegroundColor Cyan
        $RUCKUS_USER = Read-Host " "
    }

    if ([string]::IsNullOrWhiteSpace($RUCKUS_PASS)) {
        Write-Host "Ruckus 비밀번호를 입력하세요:" -ForegroundColor Cyan
        $SecurePass = Read-Host " " -AsSecureString
        $RUCKUS_PASS = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto(
            [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePass)
        )
    }

    Write-Host ""
    Write-Host "[*] 파이썬 로그인 스크립트 실행 중..." -ForegroundColor Yellow
    
    $oldPref = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    python -u "$PYTHON_SCRIPT" -u "$RUCKUS_USER" -p "$RUCKUS_PASS" -o "$COOKIE_FILE"
    $pyExitCode = $LASTEXITCODE
    $ErrorActionPreference = $oldPref

    if (($pyExitCode -ne 0) -or (-not (Test-Path $COOKIE_FILE))) {
        Write-Host "[-] 로그인 및 쿠키 생성 실패." -ForegroundColor Red
        exit 1
    }
    Write-Host "[+] 쿠키 발급 완료!" -ForegroundColor Green
} else {
    Write-Host "[+] 기존 cookies.txt 세션을 사용합니다." -ForegroundColor Green
}

(Get-Content $COOKIE_FILE) | Where-Object { $_ -and -not $_.StartsWith("#") } | Set-Content $COOKIE_FILE -Encoding utf8

# -----------------------------------------------------------------
# [단계 2] 동적 버전 목록 파싱 (200.x 버전 필터링)
# -----------------------------------------------------------------
Write-Host ""
Write-Host "[2/5] Unleashed 소프트웨어 동적 버전 검색 중..." -ForegroundColor Yellow

$pyGetVersionsScript = @"
import sys, re, requests, urllib3
from bs4 import BeautifulSoup
urllib3.disable_warnings()

cookie_file, base_url = sys.argv[1], sys.argv[2]
session = requests.Session()
session.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})

with open(cookie_file, 'r', encoding='utf-8') as f:
    for line in f:
        if not line.startswith('#') and line.strip():
            p = line.strip().split('\t')
            if len(p) >= 7:
                session.cookies.set(p[5], p[6], domain=p[0].lstrip('.'))

url = f"{base_url}/products/82/filtered_products?type=software"
try:
    r = session.get(url, verify=False, timeout=15)
    soup = BeautifulSoup(r.text, 'html.parser')
    options = soup.select("#product_software_version select[name='version_filter'] option")
    
    versions = []
    for opt in options:
        val = opt.get('value', '').strip()
        if val.startswith('200.'):
            versions.append(val)
            
    for v in sorted(versions, key=lambda x: [int(p) for p in x.split('.')], reverse=True):
        print(v)
except Exception as e:
    sys.exit(1)
"@

$tempPy = Join-Path $PSScriptRoot "temp_get_versions.py"
$pyGetVersionsScript | Out-File -FilePath $tempPy -Encoding utf8

$oldPref = $ErrorActionPreference
$ErrorActionPreference = "Continue"
$availableVersions = python $tempPy "$COOKIE_FILE" "$BASE_URL"
$ErrorActionPreference = $oldPref
Remove-Item $tempPy -ErrorAction SilentlyContinue

if (-not $availableVersions -or $availableVersions.Count -eq 0) {
    Write-Host "[-] 200.x 버전을 찾지 못했거나 동적 목록을 불러오지 못했습니다." -ForegroundColor Red
    exit 1
}

# 인터랙티브 메인 루프
while ($true) {
    # -----------------------------------------------------------------
    # [단계 3] 릴리스 버전 선택 (URL 목록을 메모리 변수에 수집)
    # -----------------------------------------------------------------
    Write-Host ""
    Write-Host "[3/5] 다운로드할 Unleashed 버전을 선택하세요:" -ForegroundColor Yellow
    
    $vIdx = 1
    foreach ($ver in $availableVersions) {
        Write-Host (" {0,2}) Unleashed {1}" -f $vIdx, $ver)
        $vIdx++
    }
    Write-Host "  0) 종료"
    Write-Host ""

    $verChoice = Read-Host "버전 선택 번호"

    if ($verChoice -eq "0") { exit 0 }

    if (-not ([int]::TryParse($verChoice, [ref]$null)) -or [int]$verChoice -lt 1 -or [int]$verChoice -gt $availableVersions.Count) {
        Write-Host "[-] 올바른 번호를 선택해주세요." -ForegroundColor Red
        continue
    }

    $selectedVersion = $availableVersions[[int]$verChoice - 1]
    Write-Host "[*] 선택된 버전 ($selectedVersion)의 다운로드 URL을 수집 중입니다..." -ForegroundColor Cyan

    $pyGetUrlsScript = @"
import sys, re, requests, urllib3
urllib3.disable_warnings()

cookie_file, base_url, version = sys.argv[1], sys.argv[2], sys.argv[3]
session = requests.Session()
session.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})

with open(cookie_file, 'r', encoding='utf-8') as f:
    for line in f:
        if not line.startswith('#') and line.strip():
            p = line.strip().split('\t')
            if len(p) >= 7:
                session.cookies.set(p[5], p[6], domain=p[0].lstrip('.'))

url = f"{base_url}/products/82/filtered_products?version={version}&type=software"
urls = []
try:
    r = session.get(url, verify=False, timeout=15)
    matches = re.findall(r'href="(/documents/[^"]+|/software/[^"]+)"', r.text)
    for m in matches:
        if "unleashed" in m.lower() and "snmp" not in m.lower():
            urls.append(base_url + m)
except: pass

for u in sorted(list(set(urls))):
    print(u)
"@

    $tempPy2 = Join-Path $PSScriptRoot "temp_get_urls.py"
    $pyGetUrlsScript | Out-File -FilePath $tempPy2 -Encoding utf8

    $oldPref = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $extractedUrls = python $tempPy2 "$COOKIE_FILE" "$BASE_URL" "$selectedVersion"
    $ErrorActionPreference = $oldPref
    Remove-Item $tempPy2 -ErrorAction SilentlyContinue

    if (-not $extractedUrls -or $extractedUrls.Count -eq 0) {
        Write-Host "[-] 해당 버전에서 다운로드할 수 있는 소프트웨어를 찾지 못했습니다." -ForegroundColor Red
        continue
    }

    # -----------------------------------------------------------------
    # [단계 4] 세부 항목 분석 및 다운로드 대상 객체 선택
    # -----------------------------------------------------------------
    Write-Host ""
    Write-Host "[4/5] 각 세부 항목의 파일 이름 및 용량 분석 중..." -ForegroundColor Yellow

    $fileList = @()
    $fCounter = 1

    foreach ($pageUrl in $extractedUrls) {
        $detailHtml = & curl.exe -k -s -b "$COOKIE_FILE" `
            -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" `
            "$pageUrl" | Out-String

        $softwareTitle = "N/A"
        if ($detailHtml -match '(?is)<title[^>]*>\s*(.*?)\s*</title>') {
            $fullTitle = [System.Net.WebUtility]::HtmlDecode($Matches[1])
            $softwareTitle = (($fullTitle -split '\|')[0].Trim() -replace '\s+', ' ')
        }

        $realFileName = ""
        if ($detailHtml -match '(?is)<dt>\s*File Name:\s*</dt>\s*<dd>\s*<a[^>]*>\s*([^<]+?)\s*</a>\s*</dd>') {
            $realFileName = [System.Net.WebUtility]::HtmlDecode($Matches[1].Trim())
        }
        if (-not $realFileName) { $realFileName = [System.IO.Path]::GetFileName($pageUrl) }

        $fileSize = "N/A"
        if ($detailHtml -match '(?is)<dt>\s*File Size:\s*</dt>\s*<dd>\s*([^<]+?)\s*</dd>') {
            $fileSize = [System.Net.WebUtility]::HtmlDecode($Matches[1].Trim())
        }

        $fileList += [PSCustomObject]@{
            Index         = $fCounter
            PageUrl       = $pageUrl
            RealFileName  = $realFileName
            SoftwareTitle = $softwareTitle
            FileSize      = $fileSize
        }
        $fCounter++
    }

    Write-Host ""
    Write-Host "----------------------------------------------------------------------------------------------------" -ForegroundColor Gray
    Write-Host ("{0,-6} | {1,-45} | {2,-15}" -f "번호", "파일 이름 (File Name)", "용량 (Size)") -ForegroundColor Cyan
    Write-Host "----------------------------------------------------------------------------------------------------" -ForegroundColor Gray

    foreach ($f in $fileList) {
        Write-Host ("{0,4}) | {1,-45} | {2,-15}" -f $f.Index, $f.RealFileName, $f.FileSize)
        Write-Host ("     └─ " + $f.SoftwareTitle) -ForegroundColor DarkGray
        Write-Host ""
    }

    Write-Host "----------------------------------------------------------------------------------------------------" -ForegroundColor Gray
    Write-Host "  a) 전체 파일 모두 선택 ($($fileList.Count)개)"
    Write-Host "  b) 이전 메뉴로 돌아가기 (버전 재선택)"
    Write-Host "  0) 종료"
    Write-Host "----------------------------------------------------------------------------------------------------" -ForegroundColor Gray

    $fileChoice = Read-Host "다운로드할 파일 번호 선택 (예: 1, 3 또는 1-5)"

    $selectedFiles = @()

    if ($fileChoice -eq "0") { exit 0 }
    elseif ($fileChoice -eq "b" -or $fileChoice -eq "B") { continue }
    elseif ($fileChoice -eq "a" -or $fileChoice -eq "A" -or [string]::IsNullOrWhiteSpace($fileChoice)) {
        $selectedFiles = $fileList
    } else {
        $selectedIndices = [System.Collections.Generic.List[int]]::new()
        $tokens = $fileChoice -split '[\s,]+'

        foreach ($token in $tokens) {
            if ($token -match '^(\d+)-(\d+)$') {
                for ($n = [int]$Matches[1]; $n -le [int]$Matches[2]; $n++) { $selectedIndices.Add($n) }
            } elseif ($token -match '^\d+$') {
                $selectedIndices.Add([int]$token)
            }
        }

        foreach ($num in ($selectedIndices | Select-Object -Unique | Sort-Object)) {
            if ($num -ge 1 -and $num -le $fileList.Count) {
                $selectedFiles += $fileList[$num - 1]
            }
        }
    }

    if ($selectedFiles.Count -eq 0) {
        Write-Host "[-] 선택된 파일이 없습니다." -ForegroundColor Red
        continue
    }

    # -----------------------------------------------------------------
    # [단계 5] 선택된 객체($selectedFiles)로 직접 다운로드 실행
    # -----------------------------------------------------------------
    Write-Host ""
    Write-Host "[5/5] 다운로드 실행 중 (총 $($selectedFiles.Count)개 파일)..." -ForegroundColor Yellow

    foreach ($fileItem in $selectedFiles) {
        $cleanUrl    = $fileItem.PageUrl.Trim()
        $downloadUrl = $cleanUrl -replace '/software/', '/software_downloads/' -replace '/documents/', '/documents_downloads/'
        $refererUrl  = $cleanUrl

        Write-Host ""
        Write-Host "[*] 다운로드 시도: $downloadUrl" -ForegroundColor Cyan

        $headRaw = & curl.exe -k -s -I -b "$COOKIE_FILE" -H "Referer: $refererUrl" "$downloadUrl" | Out-String
        
        $targetFileName = ""

        if ($headRaw -match '(?i)Location:\s*([^\r\n]+)') {
            $locationUrl = $Matches[1].Trim()
            $parsedName  = ([System.Uri]$locationUrl).Segments[-1]
            if ($parsedName -and $parsedName -notmatch '\?') {
                $targetFileName = [System.Uri]::UnescapeDataString($parsedName)
            }
        }

        if (-not $targetFileName -and $headRaw -match '(?i)filename="?([^";\r\n]+)"?') {
            $targetFileName = $Matches[1].Trim()
        }

        if (-not $targetFileName) {
            $targetFileName = $fileItem.RealFileName
        }

        # .bl7 모델명 보정
        if ($targetFileName -match '\.bl7$') {
            if ($targetFileName -notmatch '(?i)(R\d+|H\d+|T\d+|M\d+|ZF\d+)') {
                $urlSlug = ($cleanUrl -split '/')[-1]
                if ($urlSlug -match '(?i)for-(r\d+|h\d+|t\d+|m\d+|zf\d+)') {
                    $modelName = $Matches[1].ToUpper()
                    $targetFileName = "${modelName}_${targetFileName}"
                    Write-Host "  [!] 모델명 보정 적용: $targetFileName" -ForegroundColor Yellow
                }
            }
        }

        # 중복 파일 넘버링
        $saveFileName = $targetFileName
        if ($saveFileName -and (Test-Path $saveFileName)) {
            $baseName = [System.IO.Path]::GetFileNameWithoutExtension($targetFileName)
            $ext      = [System.IO.Path]::GetExtension($targetFileName)
            $counter  = 1
            while (Test-Path $saveFileName) {
                $saveFileName = "${baseName}_${counter}${ext}"
                $counter++
            }
            Write-Host "  [!] 중복 파일 발견 -> '$saveFileName'(으)로 저장합니다." -ForegroundColor Yellow
        }

        if ($saveFileName) {
            Write-Host "  [+] 대상 파일명 확인: $saveFileName" -ForegroundColor Yellow
            & curl.exe -k -L -b "$COOKIE_FILE" `
              -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)" `
              -H "Referer: $refererUrl" `
              -o "$saveFileName" "$downloadUrl"
        } else {
            & curl.exe -k -L -b "$COOKIE_FILE" `
              -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)" `
              -H "Referer: $refererUrl" `
              -J -O "$downloadUrl"
        }

        if ($saveFileName -and (Test-Path $saveFileName)) {
            Write-Host "  [+] 다운로드 완료 및 저장: $saveFileName" -ForegroundColor Green
        }
    }

    Write-Host ""
    Write-Host "[+] 선택한 작업이 완료되었습니다." -ForegroundColor Green
    
    $continueChoice = Read-Host "다른 파일도 다운로드하시겠습니까? (y/n)"
    if ($continueChoice -ne "y" -and $continueChoice -ne "Y") { break }
}

Write-Host "[+] 모든 다운로드 과정 완료." -ForegroundColor Green