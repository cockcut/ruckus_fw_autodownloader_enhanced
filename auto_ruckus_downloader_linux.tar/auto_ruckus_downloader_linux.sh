#!/usr/bin/env bash
# =================================================================
# Ruckus Firmware Auto Downloader for Rocky Linux 8 (v2.5.1)
# - Universal Ruckus Product Line Support (APs, ICX, vSZ, Unleashed)
# =================================================================

set -e

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
GRAY='\033[0;90m'
NC='\033[0m' # No Color

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COOKIE_FILE="${SCRIPT_DIR}/cookies.txt"
PYTHON_SCRIPT="${SCRIPT_DIR}/get_ruckus_cookie.py"
BASE_URL="https://support.ruckuswireless.com"

RUCKUS_USER="${RUCKUS_USER:-}"
RUCKUS_PASS="${RUCKUS_PASS:-}"

echo -e "${CYAN}=======================================================${NC}"
echo -e "${CYAN}   Ruckus Universal Firmware Auto Downloader (v2.5.1)  ${NC}"
echo -e "${CYAN}=======================================================${NC}"

# -----------------------------------------------------------------
# [단계 0] Python3 환경 및 필수 패키지 점검
# -----------------------------------------------------------------
echo -e "${YELLOW}[0/5] 필수 패키지 및 모듈 설치 상태 확인 중...${NC}"

if ! command -v python3 &> /dev/null; then
    echo -e "${YELLOW}[!] Python3가 설치되어 있지 않습니다. dnf로 설치합니다...${NC}"
    sudo dnf install -y python3 python3-pip
fi

PY_EXE="$(command -v python3)"

# 필수 파이썬 모듈 확인 및 pip 설치
MODULES=("requests:requests" "bs4:beautifulsoup4" "lxml:lxml")

for item in "${MODULES[@]}"; do
    import_name="${item%%:*}"
    pkg_name="${item##*:}"
    
    if ! "$PY_EXE" -c "import importlib.util, sys; sys.exit(0 if importlib.util.find_spec('$import_name') else 1)" &>/dev/null; then
        echo -e "${YELLOW}[!] 파이썬 ${pkg_name} (${import_name}) 모듈이 없습니다. 자동 설치를 진행합니다...${NC}"
        "$PY_EXE" -m pip install "$pkg_name" --quiet --user
    fi
done

echo -e "${GREEN}[+] 개발 및 실행 환경 검사 완료.${NC}"
echo "-------------------------------------------------"

# -----------------------------------------------------------------
# [단계 1] 쿠키 확인 및 로그인 (production_ruckus_support 만료 검사)
# -----------------------------------------------------------------
echo -e "\033[1;33m[1/5] 로그인 세션(cookies.txt) 유효성 검사 중...\033[0m"

NEED_LOGIN=false
TARGET_COOKIE_NAME="production_ruckus_support"

if [ ! -f "$COOKIE_FILE" ]; then
    echo -e "\033[1;33m[!] 쿠키 파일이 없습니다. 로그인을 진행합니다.\033[0m"
    NEED_LOGIN=true
else
    NOW_EPOCH=$(date +%s)

    # Netscape cookie format:
    # Domain | Flag | Path | Secure | Expiration | Name | Value
    TARGET_COOKIE_LINE=$(awk -F'\t' -v name="$TARGET_COOKIE_NAME" '
        $0 !~ /^#/ && NF >= 7 && $6 == name { print; exit }
    ' "$COOKIE_FILE")

    if [ -z "$TARGET_COOKIE_LINE" ]; then
        echo -e "\033[1;33m[!] '${TARGET_COOKIE_NAME}' 쿠키를 찾을 수 없습니다. 재로그인을 진행합니다.\033[0m"
        NEED_LOGIN=true
    else
        EXP_EPOCH=$(echo "$TARGET_COOKIE_LINE" | awk -F'\t' '{print $5}')

        if [[ "$EXP_EPOCH" =~ ^[0-9]+$ ]] && [ "$EXP_EPOCH" -gt 0 ]; then
            if [ "$EXP_EPOCH" -le "$NOW_EPOCH" ]; then
                echo -e "\033[1;31m[!] '${TARGET_COOKIE_NAME}' 쿠키가 만료되었습니다. 재로그인을 진행합니다.\033[0m"
                NEED_LOGIN=true
            else
                EXPIRE_TEXT=$(date -d "@$EXP_EPOCH" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "$EXP_EPOCH")
                echo -e "\033[1;32m[+] '${TARGET_COOKIE_NAME}' 쿠키가 유효합니다. (만료: ${EXPIRE_TEXT})\033[0m"
            fi
        else
            echo -e "\033[1;33m[!] '${TARGET_COOKIE_NAME}' 쿠키의 만료 시간을 확인할 수 없습니다. 재로그인을 진행합니다.\033[0m"
            NEED_LOGIN=true
        fi
    fi
fi

if [ "$NEED_LOGIN" = true ]; then
    echo ""
    RUCKUS_USER=$(echo "$RUCKUS_USER" | xargs)
    RUCKUS_PASS=$(echo "$RUCKUS_PASS" | xargs)

    if [ -z "$RUCKUS_USER" ]; then
        echo -e "\033[1;36mRuckus 이메일 계정을 입력하세요:\033[0m"
        read -r RUCKUS_USER
    fi

    if [ -z "$RUCKUS_PASS" ]; then
        echo -e "\033[1;36mRuckus 비밀번호를 입력하세요:\033[0m"
        read -rs RUCKUS_PASS
        echo ""
    fi

    echo ""
    echo -e "\033[1;33m[*] 파이썬 로그인 스크립트 실행 중...\033[0m"

    "$PY_EXE" -u "$PYTHON_SCRIPT" -u "$RUCKUS_USER" -p "$RUCKUS_PASS" -o "$COOKIE_FILE"
    PY_EXIT_CODE=$?

    if [ $PY_EXIT_CODE -ne 0 ] || [ ! -f "$COOKIE_FILE" ]; then
        echo -e "\033[1;31m[-] 로그인 및 쿠키 생성 실패.\033[0m"
        exit 1
    fi
    echo -e "\033[1;32m[+] 쿠키 발급 완료!\033[0m"
else
    echo -e "\033[1;32m[+] 기존 cookies.txt 세션이 유효합니다.\033[0m"
fi

# 빈 줄 및 주석 제거 정제
if [ -f "$COOKIE_FILE" ]; then
    sed -i '/^\s*#/d; /^\s*$/d' "$COOKIE_FILE"
fi

# -----------------------------------------------------------------
# 메인 루프
# Windows v3와 동일한 단계별 이동:
#   제품 선택 -> 버전 선택 -> 파일 선택
# -----------------------------------------------------------------
while true; do
    # -----------------------------------------------------------------
    # [단계 2] 제품 카테고리 동적 파싱
    # -----------------------------------------------------------------
    echo -e "\n${YELLOW}[2/5] Ruckus 제품 카테고리 동적 파싱 중...${NC}"

    temp_py_cat="${SCRIPT_DIR}/temp_parse_categories.py"
    cat << 'EOF' > "$temp_py_cat"
import sys, re, requests, urllib3
from bs4 import BeautifulSoup
urllib3.disable_warnings()

cookie_file, base_url = sys.argv[1], sys.argv[2]
session = requests.Session()
session.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})

with open(cookie_file, 'r', encoding='utf-8') as f:
    for line in f:
        if not line.startswith('#') and line.strip():
            p = line.strip().split('\t')
            if len(p) >= 7:
                session.cookies.set(p[5], p[6], domain=p[0].lstrip('.'))

try:
    r = session.get(f"{base_url}/software", verify=False, timeout=15)
    soup = BeautifulSoup(r.text, 'html.parser')
    allowed_groups = [
        "RUCKUS Indoor APs", "RUCKUS Outdoor APs",
        "RUCKUS ICX Switches", "Virtual SmartZone (vSZ)", "RUCKUS Unleashed"
    ]
    p_count = 1
    for group in soup.find_all('optgroup'):
        label = group.get('label', '').strip()
        is_normal = label in allowed_groups
        is_eol = (label == "EOL RUCKUS Products")
        if is_normal or is_eol:
            for opt in group.find_all('option'):
                val = opt.get('value', '').strip()
                name = opt.text.strip()
                if is_eol and not re.search(r'(Ruckus|SmartZone|ZoneDirector)', name, re.I):
                    continue
                if name.startswith('zzz'):
                    continue
                print(f"{p_count}\t{label}\t{val}\t{name}")
                p_count += 1
except Exception:
    sys.exit(1)
EOF

    product_raw_list=$("$PY_EXE" "$temp_py_cat" "$COOKIE_FILE" "$BASE_URL")
    rm -f "$temp_py_cat"

    if [ -z "$product_raw_list" ]; then
        echo -e "${RED}[-] 제품 목록을 동적으로 가져오지 못했습니다.${NC}"
        exit 1
    fi

    echo -e "\n${GRAY}----------------------------------------------------------------------------${NC}"
    printf "${CYAN}%-4s | %-24s | %s${NC}\n" "번호" "카테고리 (Group)" "제품명 (Product Name)"
    echo -e "${GRAY}----------------------------------------------------------------------------${NC}"
    while IFS=$'\t' read -r idx group pid pname; do
        printf "%4s) | %-24s | %s\n" "$idx" "$group" "$pname"
    done <<< "$product_raw_list"
    echo -e "${GRAY}----------------------------------------------------------------------------${NC}"
    echo " 0) 종료"
    echo ""

    read -rp "대상 제품 선택 번호: " pChoice
    if [ "$pChoice" = "0" ] || [ -z "$pChoice" ]; then exit 0; fi

    selected_line=$(echo "$product_raw_list" | awk -F'\t' -v ch="$pChoice" '$1 == ch {print $0}')
    if [ -z "$selected_line" ]; then
        echo -e "${RED}[-] 올바른 번호를 선택해주세요.${NC}"
        continue
    fi

    sel_group=$(echo "$selected_line" | cut -f2)
    sel_id=$(echo "$selected_line" | cut -f3)
    sel_name=$(echo "$selected_line" | cut -f4)
    echo -e "${GREEN}[+] 선택된 제품: [${sel_group}] ${sel_name} (ID: ${sel_id})${NC}"

    # [단계 3] 버전 선택 루프
    while true; do
        echo -e "\n${YELLOW}[3/5] 지원 펌웨어 버전 정보 수집 중...${NC}"

        temp_py_ver="${SCRIPT_DIR}/temp_parse_versions.py"
        cat << 'EOF' > "$temp_py_ver"
import sys, requests, urllib3
from bs4 import BeautifulSoup
urllib3.disable_warnings()

cookie_file, base_url, pid = sys.argv[1], sys.argv[2], sys.argv[3]
session = requests.Session()
session.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
with open(cookie_file, 'r', encoding='utf-8') as f:
    for line in f:
        if not line.startswith('#') and line.strip():
            p = line.strip().split('\t')
            if len(p) >= 7:
                session.cookies.set(p[5], p[6], domain=p[0].lstrip('.'))
try:
    url = f"{base_url}/products/{pid}/filtered_products?type=software"
    r = session.get(url, verify=False, timeout=15)
    soup = BeautifulSoup(r.text, 'html.parser')
    ver_div = soup.find('div', id='product_software_version')
    if ver_div:
        v_count = 1
        for opt in ver_div.find_all('option'):
            val = opt.get('value', '').strip()
            txt = opt.text.strip()
            if val and "Choose A Version" not in txt:
                print(f"{v_count}\t{val}")
                v_count += 1
except Exception:
    pass
EOF

        version_raw_list=$("$PY_EXE" "$temp_py_ver" "$COOKIE_FILE" "$BASE_URL" "$sel_id")
        rm -f "$temp_py_ver"

        selectedVersion=""
        if [ -z "$version_raw_list" ]; then
            echo -e "${YELLOW}[!] 지정 영역에서 버전을 찾지 못했습니다. 전체 조회를 진행합니다.${NC}"
        else
            echo -e "${GRAY}----------------------------------------------------------------------------${NC}"
            echo -e "${CYAN} [ 파싱된 버전 목록 ]${NC}"
            echo -e "${GRAY}----------------------------------------------------------------------------${NC}"
            while IFS=$'\t' read -r vidx vval; do
                printf "%3s) Version %s\n" "$vidx" "$vval"
            done <<< "$version_raw_list"
            echo -e "${GRAY}----------------------------------------------------------------------------${NC}"
            echo " a) 모든 버전 선택 (전체 조회)"
            echo " b) 이전 메뉴로 돌아가기 (제품 재선택)"
            echo " 0) 종료"
            echo ""

            read -rp "버전 선택 번호: " vChoice
            if [ "$vChoice" = "0" ]; then exit 0; fi
            if [ "$vChoice" = "b" ] || [ "$vChoice" = "B" ]; then
                break
            fi
            if [ "$vChoice" = "a" ] || [ "$vChoice" = "A" ]; then
                selectedVersion=""
            else
                selectedVersion=$(echo "$version_raw_list" | awk -F'\t' -v ch="$vChoice" '$1 == ch {print $2}')
                if [ -z "$selectedVersion" ]; then
                    echo -e "${RED}[-] 잘못된 번호입니다. 전체 조회를 진행합니다.${NC}"
                    selectedVersion=""
                fi
            fi
        fi

        # b를 눌렀을 때 제품 선택으로 돌아가기
        if [ "$vChoice" = "b" ] || [ "$vChoice" = "B" ]; then
            break
        fi

        echo -e "${GREEN}[+] 선택된 버전: ${selectedVersion:-ALL}${NC}"

        # [단계 4] 파일 선택 루프
        while true; do
            echo -e "\n${YELLOW}[4/5] 각 세부 항목의 파일 이름 및 용량 분석 중...${NC}"

            temp_py_files="${SCRIPT_DIR}/temp_parse_files.py"
            cat << 'EOF' > "$temp_py_files"
import sys, re, requests, urllib3
from bs4 import BeautifulSoup
urllib3.disable_warnings()

cookie_file, base_url, pid, version = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
session = requests.Session()
session.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
with open(cookie_file, 'r', encoding='utf-8') as f:
    for line in f:
        if not line.startswith('#') and line.strip():
            p = line.strip().split('\t')
            if len(p) >= 7:
                session.cookies.set(p[5], p[6], domain=p[0].lstrip('.'))

v_param = f"?version={version}&type=software" if version else "?type=software"
target_url = f"{base_url}/products/{pid}/filtered_products{v_param}"
try:
    r = session.get(target_url, verify=False, timeout=15)
    matches = re.findall(r'href="(/software/(\d+-[^"]+))"', r.text)
    sub_urls = []
    for m in matches:
        full_u = base_url + m[0]
        if full_u not in sub_urls:
            sub_urls.append(full_u)
    f_counter = 1
    for page_url in sub_urls:
        dr = session.get(page_url, verify=False, timeout=15)
        soup = BeautifulSoup(dr.text, 'html.parser')
        sw_title = soup.title.text.split('|')[0].strip() if soup.title else "N/A"
        real_file_name = ""
        dt_fn = soup.find(lambda tag: tag.name == 'dt' and 'File Name:' in tag.text)
        if dt_fn and dt_fn.find_next_sibling('dd'):
            real_file_name = dt_fn.find_next_sibling('dd').text.strip()
        if not real_file_name:
            real_file_name = page_url.split('/')[-1]
        file_size = "N/A"
        dt_fs = soup.find(lambda tag: tag.name == 'dt' and 'File Size:' in tag.text)
        if dt_fs and dt_fs.find_next_sibling('dd'):
            file_size = dt_fs.find_next_sibling('dd').text.strip()
        print(f"{f_counter}\t{page_url}\t{real_file_name}\t{file_size}\t{sw_title}")
        f_counter += 1
except Exception:
    sys.exit(1)
EOF

            file_raw_list=$("$PY_EXE" "$temp_py_files" "$COOKIE_FILE" "$BASE_URL" "$sel_id" "$selectedVersion")
            rm -f "$temp_py_files"

            if [ -z "$file_raw_list" ]; then
                echo -e "${RED}[-] 다운로드 가능한 소프트웨어 항목을 찾을 수 없습니다.${NC}"
                continue
            fi

            echo -e "\n${GRAY}----------------------------------------------------------------------------------------------------${NC}"
            printf "${CYAN}%-6s | %-45s | %-15s${NC}\n" "번호" "파일 이름 (File Name)" "용량 (Size)"
            echo -e "${GRAY}----------------------------------------------------------------------------------------------------${NC}"

            file_count=0
            while IFS=$'\t' read -r findex fpage freal fsize ftitle; do
                printf "%4s) | %-45s | %-15s\n" "$findex" "$freal" "$fsize"
                echo -e "     └─ ${GRAY}${ftitle}${NC}\n"
                file_count=$((file_count + 1))
            done <<< "$file_raw_list"

            echo -e "${GRAY}----------------------------------------------------------------------------------------------------${NC}"
            echo "  a) 전체 파일 모두 선택 (${file_count}개)"
            echo "  b) 이전 메뉴로 돌아가기 (제품/버전 재선택)"
            echo "  0) 종료"
            echo -e "${GRAY}----------------------------------------------------------------------------------------------------${NC}"

            read -rp "다운로드할 파일 번호 선택 (예: 1, 3 또는 1-5): " fChoice
            if [ "$fChoice" = "0" ]; then exit 0; fi
            if [ "$fChoice" = "b" ] || [ "$fChoice" = "B" ]; then
                break
            fi

            selected_lines=""
            if [ "$fChoice" = "a" ] || [ "$fChoice" = "A" ] || [ -z "$fChoice" ]; then
                selected_lines="$file_raw_list"
            else
                selected_indices=()
                IFS=' ' read -r -a tokens <<< "$(echo "$fChoice" | tr ',' ' ')"
                for token in "${tokens[@]}"; do
                    if [[ "$token" =~ ^([0-9]+)-([0-9]+)$ ]]; then
                        start="${BASH_REMATCH[1]}"; end="${BASH_REMATCH[2]}"
                        for ((n=start; n<=end; n++)); do selected_indices+=("$n"); done
                    elif [[ "$token" =~ ^[0-9]+$ ]]; then
                        selected_indices+=("$token")
                    fi
                done
                sorted_indices=$(printf "%s\n" "${selected_indices[@]}" | sort -nu)
                for num in $sorted_indices; do
                    matched=$(echo "$file_raw_list" | awk -F'\t' -v n="$num" '$1 == n {print $0}')
                    if [ -n "$matched" ]; then
                        selected_lines="${selected_lines}${matched}"$'\n'
                    fi
                done
                selected_lines="$(echo "$selected_lines" | sed '/^$/d')"
            fi

            if [ -z "$selected_lines" ]; then
                echo -e "${RED}[-] 선택된 파일이 없습니다.${NC}"
                continue
            fi

            selected_count=$(echo "$selected_lines" | wc -l)
            echo -e "\n${YELLOW}[5/5] 다운로드 실행 중 (총 ${selected_count}개 파일)...${NC}"

            cleanProductName=$(echo "$sel_name" | sed -E 's/[^a-zA-Z0-9_-]/_/g; s/_+/_/g; s/^_|_$//g')

            while IFS=$'\t' read -r findex fpage freal fsize ftitle; do
                downloadUrl=$(echo "$fpage" | sed 's|/software/|/software_downloads/|g; s|/documents/|/documents_downloads/|g')
                echo -e "\n${CYAN}[*] 다운로드 시도: ${downloadUrl}${NC}"

                # 파일명은 [4/5]에서 이미 실제 File Name 항목으로 파싱한 값을 우선 사용한다.
                # HEAD 응답의 첫 Location은 인증 리다이렉트(/login)일 수 있으므로
                # Location URL의 마지막 경로를 파일명으로 사용하면 안 된다.
                targetFileName="$freal"

                # 실제 응답에 Content-Disposition filename이 있는 경우에만 파일명을 보정한다.
                # 리다이렉트를 따라가 최종 응답 헤더에서만 filename을 찾는다.
                headRaw=$(curl -k -s -I -L -b "$COOKIE_FILE" \
                    -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)" \
                    -H "Referer: $fpage" "$downloadUrl")

                cdLine=$(echo "$headRaw" | grep -i "Content-Disposition:.*filename=" | tail -n 1)
                if [ -n "$cdLine" ]; then
                    headerFileName=$(echo "$cdLine" | sed -E 's/.*filename="?([^";\r\n]+)"?.*/\1/' | tr -d '\r')
                    if [ -n "$headerFileName" ] && [ "$headerFileName" != "login" ]; then
                        targetFileName="$headerFileName"
                    fi
                fi

                if [[ "$targetFileName" =~ \.bl7$ ]] && [[ ! "$targetFileName" =~ ^"$cleanProductName" ]]; then
                    if [[ "$targetFileName" =~ ^[0-9]+[0-9\.]*\.bl7$ ]]; then
                        targetFileName="${cleanProductName}_${targetFileName}"
                        echo -e "${YELLOW}  [!] 모델명 보정 적용: ${targetFileName}${NC}"
                    fi
                fi

                # 인증 리다이렉트 경로(login)를 파일명으로 사용하지 않는다.
                if [ -z "$targetFileName" ] || [ "$targetFileName" = "login" ]; then
                    targetFileName="$freal"
                fi

                saveFileName="$targetFileName"
                if [ -f "$saveFileName" ]; then
                    echo -e "${YELLOW}  [!] 기존 파일 발견 -> '${saveFileName}' 이어서 다운로드를 시도합니다.${NC}"
                fi
                echo -e "${YELLOW}  [+] 대상 파일명 확정: ${saveFileName}${NC}"

                # -C - : 중단된 동일 파일이 있으면 기존 크기 이후부터 이어받기
                curl -k -L -C - --retry 5 --retry-delay 3 --retry-max-time 600 -b "$COOKIE_FILE" \
                    -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)" \
                    -H "Referer: $fpage" \
                    -o "$saveFileName" "$downloadUrl"

                if [ -f "$saveFileName" ]; then
                    echo -e "${GREEN}  [+] 다운로드 완료: ${saveFileName}${NC}"
                fi
            done <<< "$selected_lines"

            echo -e "\n${GREEN}[+] 다운로드 작업이 완료되었습니다.${NC}"
            read -rp "다른 파일도 다운로드하시겠습니까? (y/n): " continueChoice
            if [[ "$continueChoice" = "y" || "$continueChoice" = "Y" ]]; then
                # 같은 제품/버전의 [4/5] 파일 목록으로 돌아감
                continue
            fi
            exit 0
        done

        # [4/5]에서 b -> 현재 제품의 [3/5] 버전 목록으로 돌아감
        continue
    done
done