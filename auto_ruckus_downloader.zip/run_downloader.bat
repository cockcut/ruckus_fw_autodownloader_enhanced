@echo off
chcp 65001 > nul
title Ruckus Product Firmware Auto Downloader
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0auto_ruckus_downloader.ps1"
pause