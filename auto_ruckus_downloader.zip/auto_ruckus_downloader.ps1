﻿# =================================================================
# Ruckus Firmware Auto Downloader (v2.5.1)
# - Universal Ruckus Product Line Support (APs, ICX, vSZ, Unleashed)
# =================================================================

$ErrorActionPreference = "Stop"

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13

$COOKIE_FILE   = Join-Path $PSScriptRoot "cookies.txt"
$PYTHON_SCRIPT = Join-Path $PSScriptRoot "get_ruckus_cookie.py"
$BASE_URL      = "https://support.ruckuswireless.com"

$RUCKUS_USER = $env:RUCKUS_USER
$RUCKUS_PASS = $env:RUCKUS_PASS

Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host "   Ruckus Universal Firmware Auto Downloader (v2.5.1)" -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan

# -----------------------------------------------------------------
# [단계 0] Python 환경 및 필수 패키지 점검
# -----------------------------------------------------------------
Write-Host "[0/5] 필수 패키지 및 모듈 설치 상태 확인 중..." -ForegroundColor Yellow

$pythonCmd = Get-Command python -ErrorAction SilentlyContinue
if (-not $pythonCmd -or $pythonCmd.Source -match "WindowsApps") {
    Write-Host "[!] Python이 설치되어 있지 않습니다. winget으로 설치를 진행합니다..." -ForegroundColor Yellow
    winget install --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
}

$modules = @{
    "requests" = "requests"
    "bs4"      = "beautifulsoup4"
    "lxml"     = "lxml"
}

foreach ($importName in $modules.Keys) {
    $pkgName = $modules[$importName]
    python -c "import $importName" 2>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[!] 파이썬 $pkgName ($importName) 모듈이 없습니다. 자동 설치를 진행합니다..." -ForegroundColor Yellow
        python -m pip install $pkgName --quiet
    }
}
Write-Host "[+] 개발 및 실행 환경 검사 완료." -ForegroundColor Green
Write-Host "-------------------------------------------------"

# -----------------------------------------------------------------
# [단계 1] 쿠키 확인 및 로그인
# -----------------------------------------------------------------
Write-Host "[1/5] 로그인 세션(cookies.txt) 검사 중..." -ForegroundColor Yellow

if (-not (Test-Path $COOKIE_FILE)) {
    Write-Host "[!] 쿠키 파일이 없습니다. 로그인을 진행합니다." -ForegroundColor Yellow
    Write-Host ""

    if ($RUCKUS_USER) { $RUCKUS_USER = $RUCKUS_USER.Trim() }
    if ($RUCKUS_PASS) { $RUCKUS_PASS = $RUCKUS_PASS.Trim() }

    if ([string]::IsNullOrWhiteSpace($RUCKUS_USER)) {
        Write-Host "Ruckus 이메일 계정을 입력하세요:" -ForegroundColor Cyan
        $RUCKUS_USER = Read-Host " "
    }

    if ([string]::IsNullOrWhiteSpace($RUCKUS_PASS)) {
        Write-Host "Ruckus 비밀번호를 입력하세요:" -ForegroundColor Cyan
        $SecurePass = Read-Host " " -AsSecureString
        $RUCKUS_PASS = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto(
            [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePass)
        )
    }

    Write-Host ""
    Write-Host "[*] 파이썬 로그인 스크립트 실행 중..." -ForegroundColor Yellow

    $oldPref = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    python -u "$PYTHON_SCRIPT" -u "$RUCKUS_USER" -p "$RUCKUS_PASS" -o "$COOKIE_FILE"
    $pyExitCode = $LASTEXITCODE
    $ErrorActionPreference = $oldPref

    if (($pyExitCode -ne 0) -or (-not (Test-Path $COOKIE_FILE))) {
        Write-Host "[-] 로그인 및 쿠키 생성 실패." -ForegroundColor Red
        exit 1
    }
    Write-Host "[+] 쿠키 발급 완료!" -ForegroundColor Green
} else {
    Write-Host "[+] 기존 cookies.txt 세션을 사용합니다." -ForegroundColor Green
}

(Get-Content $COOKIE_FILE) | Where-Object { $_ -and -not $_.StartsWith("#") } | Set-Content $COOKIE_FILE -Encoding utf8

# 인터랙티브 메인 루프
while ($true) {

    # -----------------------------------------------------------------
    # [단계 2] 제품 카테고리 동적 파싱
    # -----------------------------------------------------------------
    Write-Host ""
    Write-Host "[2/5] Ruckus 제품 카테고리 동적 파싱 중..." -ForegroundColor Yellow

    $softwareHtml = & curl.exe -k -s -b "$COOKIE_FILE" `
      -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" `
      "$BASE_URL/software" | Out-String

    $optGroupMatches = [regex]::Matches($softwareHtml, '(?s)<optgroup label="([^"]+)">\s*(.*?)\s*</optgroup>')

    $allowedGroups = @(
        "RUCKUS Indoor APs",
        "RUCKUS Outdoor APs",
        "RUCKUS ICX Switches",
        "Virtual SmartZone (vSZ)",
        "RUCKUS Unleashed"
    )

    $productList = @()
    $pCount = 1

    foreach ($group in $optGroupMatches) {
        $groupLabel = $group.Groups[1].Value.Trim()
        $groupContent = $group.Groups[2].Value

        $isNormalGroup = $allowedGroups -contains $groupLabel
        $isEolGroup    = $groupLabel -eq "EOL RUCKUS Products"

        if ($isNormalGroup -or $isEolGroup) {
            $optionMatches = [regex]::Matches($groupContent, '<option value="(\d+)">([^<]+)</option>')

            foreach ($opt in $optionMatches) {
                $val  = $opt.Groups[1].Value.Trim()
                $name = $opt.Groups[2].Value.Trim()

                if ($isEolGroup -and ($name -notmatch '(?i)(Ruckus|SmartZone|ZoneDirector)')) { continue }
                if ($name -match '^zzz') { continue }

                $productList += [PSCustomObject]@{
                    Index = $pCount
                    Group = $groupLabel
                    Id    = $val
                    Name  = $name
                }
                $pCount++
            }
        }
    }

    if ($productList.Count -eq 0) {
        Write-Host "[-] 제품 목록을 동적으로 가져오지 못했습니다." -ForegroundColor Red
        exit 1
    }

    Write-Host ""
    Write-Host "----------------------------------------------------------------------------" -ForegroundColor Gray
    Write-Host ("{0,-4} | {1,-24} | {2}" -f "번호", "카테고리 (Group)", "제품명 (Product Name)") -ForegroundColor Cyan
    Write-Host "----------------------------------------------------------------------------" -ForegroundColor Gray

    foreach ($p in $productList) {
        Write-Host ("{0,4}) | {1,-24} | {2}" -f $p.Index, $p.Group, $p.Name)
    }

    Write-Host "----------------------------------------------------------------------------" -ForegroundColor Gray
    Write-Host " 0) 종료"
    Write-Host ""

    $pChoice = Read-Host "대상 제품 선택 번호"
    if ($pChoice -eq "0" -or [string]::IsNullOrWhiteSpace($pChoice)) { exit 0 }

    $selectedProduct = $productList | Where-Object { $_.Index -eq [int]$pChoice }
    if (-not $selectedProduct) {
        Write-Host "[-] 올바른 번호를 선택해주세요." -ForegroundColor Red
        continue
    }
    Write-Host "[+] 선택된 제품: [$($selectedProduct.Group)] $($selectedProduct.Name) (ID: $($selectedProduct.Id))" -ForegroundColor Green

    # -----------------------------------------------------------------
    # [단계 3] 지원 버전 목록 파싱
    # -----------------------------------------------------------------
    Write-Host ""
    Write-Host "[3/5] 지원 펌웨어 버전 정보 수집 중..." -ForegroundColor Yellow

    $filterUrl = "$BASE_URL/products/$($selectedProduct.Id)/filtered_products?type=software"
    $filterHtml = & curl.exe -k -s -b "$COOKIE_FILE" `
      -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" `
      "$filterUrl" | Out-String

    $versionList = @()

    if ($filterHtml -match "(?s)<div\s+id=['""]product_software_version['""]\s*>(.*?)</div>") {
        $versionDivContent = $Matches[1]
        $optionMatches = [regex]::Matches($versionDivContent, '<option\s+value=["'']([^"'']*)["'']>([^<]+)</option>')
        
        $vCount = 1
        foreach ($om in $optionMatches) {
            $vVal  = $om.Groups[1].Value.Trim()
            $vText = $om.Groups[2].Value.Trim()

            if ($vVal -ne "" -and $vText -notmatch "Choose A Version") {
                $versionList += [PSCustomObject]@{
                    Index   = $vCount
                    Version = $vVal
                }
                $vCount++
            }
        }
    }

    if ($versionList.Count -eq 0) {
        Write-Host "[!] 지정 영역에서 버전을 찾지 못했습니다. 전체 조회를 진행합니다." -ForegroundColor Yellow
        $selectedVersion = ""
    } else {
        Write-Host "----------------------------------------------------------------------------" -ForegroundColor Gray
        Write-Host " [ 파싱된 버전 목록 ]" -ForegroundColor Cyan
        Write-Host "----------------------------------------------------------------------------" -ForegroundColor Gray
        
        foreach ($v in $versionList) {
            Write-Host ("{0,3}) Version {1}" -f $v.Index, $v.Version)
        }
        
        Write-Host "----------------------------------------------------------------------------" -ForegroundColor Gray
        Write-Host " a) 모든 버전 선택 (전체 조회)"
        Write-Host " b) 이전 메뉴로 돌아가기 (제품 재선택)"
        Write-Host " 0) 종료"
        Write-Host ""

        $vChoice = Read-Host "버전 선택 번호"
        if ($vChoice -eq "0") { exit 0 }
        elseif ($vChoice -eq "b" -or $vChoice -eq "B") { continue }
        elseif ($vChoice -eq "a" -or $vChoice -eq "A") { 
            $selectedVersion = "" 
        }
        else {
            $selectedObj = $versionList | Where-Object { $_.Index -eq [int]$vChoice }
            if ($selectedObj) {
                $selectedVersion = $selectedObj.Version
            } else {
                Write-Host "[-] 잘못된 번호입니다. 전체 조회를 진행합니다." -ForegroundColor Red
                $selectedVersion = ""
            }
        }
    }

    Write-Host "[+] 선택된 버전: $(if($selectedVersion){ $selectedVersion } else { 'ALL' })" -ForegroundColor Green

    # -----------------------------------------------------------------
    # [단계 4] 세부 소프트웨어 항목 파싱
    # -----------------------------------------------------------------
    Write-Host ""
    Write-Host "[4/5] 각 세부 항목의 파일 이름 및 용량 분석 중..." -ForegroundColor Yellow

    $versionParam = if ($selectedVersion) { "?version=$selectedVersion&type=software" } else { "?type=software" }
    $targetSoftwareListUrl = "$BASE_URL/products/$($selectedProduct.Id)/filtered_products$versionParam"

    $swListHtml = & curl.exe -k -s -b "$COOKIE_FILE" `
      -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" `
      "$targetSoftwareListUrl" | Out-String

    $subLinkMatches = [regex]::Matches($swListHtml, 'href="(/software/(\d+-[^"]+))"')
    $subUrls = @()

    foreach ($sm in $subLinkMatches) {
        $fullSubUrl = "$BASE_URL" + $sm.Groups[1].Value
        if ($subUrls -notcontains $fullSubUrl) { $subUrls += $fullSubUrl }
    }

    if ($subUrls.Count -eq 0) {
        Write-Host "[-] 다운로드 가능한 소프트웨어 항목을 찾을 수 없습니다." -ForegroundColor Red
        continue
    }

    $fileList = @()
    $fCounter = 1

    foreach ($pageUrl in $subUrls) {
        $detailHtml = & curl.exe -k -s -b "$COOKIE_FILE" `
          -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" `
          "$pageUrl" | Out-String

        $softwareTitle = "N/A"
        if ($detailHtml -match '(?is)<title[^>]*>\s*(.*?)\s*</title>') {
            $fullTitle = [System.Net.WebUtility]::HtmlDecode($Matches[1])
            $softwareTitle = (($fullTitle -split '\|')[0].Trim() -replace '\s+', ' ')
        }

        $realFileName = ""
        if ($detailHtml -match '(?is)<dt>\s*File Name:\s*</dt>\s*<dd>\s*<a[^>]*>\s*([^<]+?)\s*</a>\s*</dd>') {
            $realFileName = [System.Net.WebUtility]::HtmlDecode($Matches[1].Trim())
        }
        if (-not $realFileName) { $realFileName = [System.IO.Path]::GetFileName($pageUrl) }

        $fileSize = "N/A"
        if ($detailHtml -match '(?is)<dt>\s*File Size:\s*</dt>\s*<dd>\s*([^<]+?)\s*</dd>') {
            $fileSize = [System.Net.WebUtility]::HtmlDecode($Matches[1].Trim())
        }

        $fileList += [PSCustomObject]@{
            Index         = $fCounter
            PageUrl       = $pageUrl
            RealFileName  = $realFileName
            SoftwareTitle = $softwareTitle
            FileSize      = $fileSize
        }
        $fCounter++
    }

    # 파일 선택 목록 출력 및 파싱 (1, 3 또는 1-5 범위 파싱 내장)
    Write-Host ""
    Write-Host "----------------------------------------------------------------------------------------------------" -ForegroundColor Gray
    Write-Host ("{0,-6} | {1,-45} | {2,-15}" -f "번호", "파일 이름 (File Name)", "용량 (Size)") -ForegroundColor Cyan
    Write-Host "----------------------------------------------------------------------------------------------------" -ForegroundColor Gray

    foreach ($f in $fileList) {
        Write-Host ("{0,4}) | {1,-45} | {2,-15}" -f $f.Index, $f.RealFileName, $f.FileSize)
        Write-Host ("     └─ " + $f.SoftwareTitle) -ForegroundColor DarkGray
        Write-Host ""
    }

    Write-Host "----------------------------------------------------------------------------------------------------" -ForegroundColor Gray
    Write-Host "  a) 전체 파일 모두 선택 ($($fileList.Count)개)"
    Write-Host "  b) 이전 메뉴로 돌아가기 (제품/버전 재선택)"
    Write-Host "  0) 종료"
    Write-Host "----------------------------------------------------------------------------------------------------" -ForegroundColor Gray

    $fChoice = Read-Host "다운로드할 파일 번호 선택 (예: 1, 3 또는 1-5)"

    $selectedFiles = @()

    if ($fChoice -eq "0") { exit 0 }
    elseif ($fChoice -eq "b" -or $fChoice -eq "B") { continue }
    elseif ($fChoice -eq "a" -or $fChoice -eq "A" -or [string]::IsNullOrWhiteSpace($fChoice)) {
        $selectedFiles = $fileList
    } else {
        $selectedIndices = [System.Collections.Generic.List[int]]::new()
        $tokens = $fChoice -split '[\s,]+'

        foreach ($token in $tokens) {
            if ($token -match '^(\d+)-(\d+)$') {
                for ($n = [int]$Matches[1]; $n -le [int]$Matches[2]; $n++) { $selectedIndices.Add($n) }
            } elseif ($token -match '^\d+$') {
                $selectedIndices.Add([int]$token)
            }
        }

        foreach ($num in ($selectedIndices | Select-Object -Unique | Sort-Object)) {
            if ($num -ge 1 -and $num -le $fileList.Count) { $selectedFiles += $fileList[$num - 1] }
        }
    }

    if ($selectedFiles.Count -eq 0) {
        Write-Host "[-] 선택된 파일이 없습니다." -ForegroundColor Red
        continue
    }

    # -----------------------------------------------------------------
    # [단계 5] 다운로드 진행 및 파일명 정제
    # -----------------------------------------------------------------
    Write-Host ""
    Write-Host "[5/5] 다운로드 실행 중 (총 $($selectedFiles.Count)개 파일)..." -ForegroundColor Yellow

    $cleanProductName = $selectedProduct.Name -replace '[^a-zA-Z0-9_-]', '_' -replace '_+', '_' -replace '^_|_$', ''

    foreach ($fileItem in $selectedFiles) {
        $pageUrl     = $fileItem.PageUrl
        $downloadUrl = $pageUrl -replace '/software/', '/software_downloads/' -replace '/documents/', '/documents_downloads/'
        
        Write-Host ""
        Write-Host "[*] 다운로드 시도: $downloadUrl" -ForegroundColor Cyan

        $headRaw = & curl.exe -k -s -I -b "$COOKIE_FILE" `
          -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)" `
          -H "Referer: $pageUrl" "$downloadUrl" | Out-String

        $targetFileName = ""

        if ($headRaw -match '(?i)Location:\s*([^\r\n]+)') {
            $locationUrl = $Matches[1].Trim()
            $parsedName  = ([System.Uri]$locationUrl).Segments[-1]
            if ($parsedName -and $parsedName -notmatch '\?') {
                $targetFileName = [System.Uri]::UnescapeDataString($parsedName)
            }
        }

        if (-not $targetFileName -and $headRaw -match '(?i)filename="?([^";\r\n]+)"?') {
            $targetFileName = $Matches[1].Trim()
        }

        if (-not $targetFileName) {
            $targetFileName = $fileItem.RealFileName
        }

        # .bl7 파일명 보정 (모델명 결합)
        if ($targetFileName -match '\.bl7$' -and $targetFileName -notmatch "^$cleanProductName") {
            if ($targetFileName -match '^\d+[\d\.]+\.bl7$') {
                $targetFileName = "${cleanProductName}_${targetFileName}"
                Write-Host "  [!] 모델명 보정 적용: $targetFileName" -ForegroundColor Yellow
            }
        }

        # 중복 파일 넘버링
        $saveFileName = $targetFileName
        if (Test-Path $saveFileName) {
            $baseName  = [System.IO.Path]::GetFileNameWithoutExtension($targetFileName)
            $ext       = [System.IO.Path]::GetExtension($targetFileName)
            $counter   = 1
            while (Test-Path $saveFileName) {
                $saveFileName = "${baseName}_${counter}${ext}"
                $counter++
            }
            Write-Host "  [!] 중복 파일 발견 -> '$saveFileName'(으)로 저장합니다." -ForegroundColor Yellow
        }

        Write-Host "  [+] 대상 파일명 확정: $saveFileName" -ForegroundColor Yellow
        & curl.exe -k -L -b "$COOKIE_FILE" `
          -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)" `
          -H "Referer: $pageUrl" `
          -o "$saveFileName" "$downloadUrl"

        if (Test-Path $saveFileName) {
            Write-Host "  [+] 다운로드 완료: $saveFileName" -ForegroundColor Green
        }
    }

    Write-Host ""
    Write-Host "[+] 모든 다운로드 작업이 완료되었습니다." -ForegroundColor Green
    
    $continueChoice = Read-Host "다른 파일도 다운로드하시겠습니까? (y/n)"
    if ($continueChoice -ne "y" -and $continueChoice -ne "Y") { break }
}

Write-Host "[+] 프로그램을 종료합니다." -ForegroundColor Cyan